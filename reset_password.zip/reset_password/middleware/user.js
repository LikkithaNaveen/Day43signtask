const { isValidObjectId } = require("mongoose");
const passwordreset = require("../model/resetpassword");
const { sendError } = require("../utlis/helper");

exports.isValidresettoken=async(req,res,next)=>{

    const { token, userId } = req.body;

    if (!token.trim() || !isValidObjectId(userId))
        return sendError(res, "Invalid request!");

    const resetToken = await passwordreset.findOne({ owner: userId });
    if (!resetToken)
        return sendError(res, "Unauthorized access, invalid request!");

    // const matched = await resetToken.compareToken(token);
    // if (!matched) return sendError(res, "Unauthorized access, invalid requestsssssssss!");

    req.resetToken = resetToken;
    next();


}