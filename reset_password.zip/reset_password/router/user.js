const express = require('express');
const router = express.Router()
const { create, signin, verifyEmail, resetemail, forgetpassword, resetpasswordsuccesstoken, sendresettoken } = require('../controller/user');
const { validateuser, validate, validatepassword, signinvalidator } = require('../middleware/validator');
const { isValidresettoken } = require('../middleware/user');

router.post('/create', validateuser, validate, create)
router.post('/signin', signin,validate,signinvalidator)

router.post('/verifyemail', verifyEmail)

router.post('/resetemail', resetemail)

router.post('/forgetpassword', forgetpassword)

router.post('/verifypassresettoken', isValidresettoken, sendresettoken)

router.post('/resetpasswordsuccesstoken', validatepassword, validate, isValidresettoken, resetpasswordsuccesstoken)


//router.post('resetemail',resetemail)


module.exports = router