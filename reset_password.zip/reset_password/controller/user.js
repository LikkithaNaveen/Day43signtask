
const { sendError, generateRandombytes } = require('../utlis/helper')
const Verificationtoken = require('../model/verification')
const jwt = require('jsonwebtoken');
const { generateOTP, generatetemplate, plaintext, resetpasswordlink,resetpassword, resetpasswordsuccess} = require('../utlis/mail');
const { mailtransport } = require('../utlis/mail');
const { isValidObjectId } = require('mongoose');
const user = require('../model/user');
const resetpasswordtoken = require('../model/resetpassword');


// exports.create=async (req,res)=>{
//     const {name,email,password} = req.body;
//     const Use=await user.findOne({email})
//     if(Use)
//     {
//         return res.status(400).json({success:false,error:'This email is already exists'})
//     }
//     const addMentor = new user({
//         name,
//         email,  
//         password
//     })


//     const OTP=generateOTP()
//     const verificationtoken=new Verificationtoken({
//         owner:addMentor._id,
//         token:OTP, 
//     });
//     await  verificationtoken.save()   
//     await addMentor.save()

//     mailtransport().sendMail({
//         from:"emailverification@gmail.com",
//         to:addMentor.email,
//         subject:"verify your email account",
//         html:generatetemplate(OTP)

//     })
//     res.send(addMentor)

// }

exports.signin = async (req, res) => {
    const { email, password } = req.body


    const Use = await user.findOne({email})
    if (!Use) return sendError(res, "Email/password Mismatch")

    const isMatched = await Use.comparePassword(password)
    if (!isMatched) return sendError(res, "email/password doesn't match")

    const  { _id , name   }=Use

    const token = jwt.sign({ userId: _id }, process.env.JWT_SECRET)

    res.json({
        success: true,
        users: { name: Use.name, email: Use.email, id:Use._id, token: token }
    })
}


// exports.verifyEmail = async(req,res)=>{
//     const {userId,otp}=req.body

//     if(!userId ||!otp.trim())
//     return sendError(res,"Invalid request,missing parameters")

//     if(!isValidObjectId(userId))  return sendError(res,"Invalid user Id")

//     const Use=await user.findById(userId)
//     if(!Use)  return sendError(res,"sorry,user nottt found")


//     if(Use.verified)  return sendError(res,"this account is already verified")

//     const token=await Verificationtoken.findOne({owner:userId})
//     if(!token)  return sendError(res,"sorry,user not  found")


//     const isMatched=await token.compareToken(otp)
//     if(!isMatched)  return sendError(res,"prrovide valid token")


//     Use.verified=true
//     await Verificationtoken.findByIdAndDelete(token._id)
//     await Use.save()

//     mailtransport().sendMail({
//         from:"emailverification@gmail.com",
//         to:user.email,  
//         subject:"verify your email account",
//         html:plaintext("Email verified successfull","Thanks for connecting for us"),
//     })

//     res.json({success:true,message:" Email is verified",
//         users:{name:user.name,email:user.email,id:user._id,token:token}})

// }

exports.create = async (req, res) => {
    const { name, email, password } = req.body

    const oldUser = await user.findOne({ email });

    if (oldUser) return res.status(401).json({ error: "This email is already in use!" });

    const newUser = new user({ name, email, password })
    await newUser.save()

    // generate 6 digit otp
    let OTP = "";
    for (let i = 1; i <= 5; i++) {
        const randomVal = Math.round(Math.random() * 9);
        OTP += randomVal;
    }

    // store otp inside our db
    const newEmailVerificationToken = new Verificationtoken({ owner: newUser._id, token: OTP })

    await newEmailVerificationToken.save()

    // send that otp to our user

    // var transport = nodemailer.createTransport({
    //   host: "smtp.mailtrap.io",
    //   port: 2525,
    //   auth: {
    //     user: "f29ed41f1f4bd3",
    //     pass: "db3edd88e2927f"
    //   }
    // });

    mailtransport().sendMail({
        from: 'verification@reviewapp.com',
        to: newUser.email,
        subject: 'Email Verification',
        html: generatetemplate(OTP)

    })

    res.status(201).json({ message: 'Please verify you email. OTP has been sent to your email account!' })
};

exports.verifyEmail = async (req, res) => {
    const { userId, OTP } = req.body

    if (!isValidObjectId(userId)) return res.json({ error: "Invalid user!" })

    const Use = await user.findById(userId)
    if (!Use) return res.json({ error: "user not found!" })

    if (Use.isVerified) return res.json({ error: "user is already verified!" })

    const token = await Verificationtoken.findOne({ owner: userId })
    if (!token) return res.json({ error: 'token not found!' })

    const isMatched = await token.compareToken(OTP)
    if (!isMatched) return res.json({ error: 'Please submit a valid OTP!' })

    Use.isVerified = true;
    await Use.save();

    await Verificationtoken.findByIdAndDelete(token._id);



    mailtransport().sendMail({
        from: 'verification@reviewapp.com',
        to: Use.email,
        subject: 'Welcome Email',
        html: plaintext("Email verified successfull", "Thanks for connecting for us")
    })

    res.json({ message: "Your email is verified." })
}


exports.resetemail = async (req, res) => {
    const { userId } = req.body

    const Use = await user.findById(userId)
    if (!Use) return res.json({ error: "user not found!" })

    if (Use.isVerified) return res.json({ error: " this email user is already verified!" })

    const token = await Verificationtoken.findOne({ owner: userId })
    if (token) return res.json({ error: ' After one hour you can get another request' })

    if (token)
        return res.json({ error: "Only after one hour you can request for another token!" });


    let OTP = "";
    for (let i = 1; i <= 5; i++) {
        const randomVal = Math.round(Math.random() * 9);
        OTP += randomVal;
    }
    //store otp to db
    const newverification = new Verificationtoken({ owner: userId, token: OTP })
    await newverification.save()

    mailtransport().sendMail({
        from: 'verification@reviewapp.com',
        to: Use.email,
        subject: 'Email Verification',
        html: plaintext("You verification OTP", OTP)

    })
    res.json({ message: "New OTP send to your register Email" })


}

exports.forgetpassword = async (req, res) => {
    const { email } = req.body

    if (!email) return sendError(res, "Email is missing")

    const Use = await user.findOne({ email })
    if (!Use) return sendError(res, 'User not found!', 404)

    const alreadytoken = await resetpasswordtoken.findOne({ owner: Use._id })
    if (alreadytoken) 
    return res.json({ error: ' After one hour you can get another request' })

    const token = await generateRandombytes();
    const newpassword = await resetpasswordtoken({ owner: Use._id, token })
    await newpassword.save()

    const resetpasswordurl = `http://locolhost:8000/resetpassword?token=${token}&id=${Use._id}`
    

    mailtransport().sendMail({
        from: 'security@reviewapp.com',
        to: Use.email,
        subject: 'Reset Password Link',
        html: resetpasswordlink(resetpasswordurl,email)

    })

    res.json({ message: "Link sent to your Email" })

}

exports.sendresettoken =  (req, res) => {
    res.json({valid:"true"})
}


exports.resetpasswordsuccesstoken = async (req, res) => {
    const { newpassword,userId } = req.body

    const Use=await user.findById(userId)
    const matchedpassword=await Use.comparePassword(newpassword)
   
    if (matchedpassword) return sendError(res,'the new password must not be old password' )

    Use.password=newpassword
    await Use.save()

    await resetpasswordtoken.findByIdAndDelete(req.resetToken._id)

    mailtransport().sendMail({
        from: 'security@reviewapp.com',
        to: Use.email,
        subject: 'password reset successfully',
        html: resetpasswordsuccess()

    })

    res.json({ message: "Password Reset successfully,now you can use new password!!" })
   
}