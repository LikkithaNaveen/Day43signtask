
const express=require('express')
require("dotenv").config()
require("./db")
const app=express()
const user=require('./model/user')
const userrouter=require('./router/user')


const port=process.env.port || 8000

app.use(express.json())

app.use('/api/user',userrouter)

app.listen(port,()=>{
    console.log("running successfully")
})

